# Trends and Disparities of Dangerous Humid Heat Exposure Among Incarcerated People in the United States

Cascade Tuholske, Victoria D. Lynch, Raenita Spriggs, Anne E. Nigra, Robbie M. Parks

## Introduction

## Code

### Data preparation (data_prep) list:

Please note, the html files are here for reference and cannot be run as the data are too large to include in repo.

a_01_prepare_wbgt_prison_data - load WBGT prison data

a_02_prepare_wbgt_prison_summary_data - prepare WBGT prison summary data

a_03_prepare_wbgt_state_data - load WBGT state data

a_04_prepare_wbgt_state_summary_data - prepare WBGT state summary data

### Data exploration (data_exploration) list:

b_00_prisons_explore - Basic facts about prisons

b_01_figure_1 - Plot Figure 1

b_02_figure_2 - Plot Figure 2

# list of important file locations to avoid having to repeat every time loading files
raw_wbgt_prison_data = "~/git/PRISM-grids-into-FIPS-ZIP-censustract-USA/output/prison/wbgtmax/"
raw_wbgt_state_data = "~/git/PRISM-grids-into-FIPS-ZIP-censustract-USA/output/fips/wbgtmax/"
new_population_data = "~/data/cdc_population_monthly_infer/output/population_processed/10_year_age_groups/"
